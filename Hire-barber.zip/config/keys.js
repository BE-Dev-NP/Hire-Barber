dbPassword = 'mongodb+srv://saadii:'+ encodeURIComponent('success1636') + '@mydata-ddjmf.mongodb.net/test?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
